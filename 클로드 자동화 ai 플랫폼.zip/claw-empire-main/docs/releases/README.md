# Releases

- [`v1.0.3`](v1.0.3.md) - Message delivery resilience hardening (idempotency/retry/audit verification) + review workflow guardrails for loop control
- [`v1.0.2`](v1.0.2.md) - Agent token optimization: auto project context, recent changes sharing, CLAUDE.md generation, shared MVP code review policy + explicit warning-fix override
- [`v1.0.1`](v1.0.1.md) - OAuth multi-account pool, Office account routing, direct chat-to-task execution, mobile virtual controls
