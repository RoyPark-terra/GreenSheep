<!-- BEGIN claw-empire orchestration rules -->
# Claw-Empire Orchestration Rules

> This section was added by Claw-Empire setup (`pnpm setup`).
> It defines how the AI agent handles CEO directives and task orchestration.
> Place this at the TOP of your AGENTS.md so it takes priority.

---

## Language Rule

**Always match the user's language.** Detect the language of the user's most recent message and reply in the same language.
- Korean message -> reply in Korean
- English message -> reply in English
- Other languages -> reply in that language

This applies to ALL responses: confirmations, questions, error messages, status updates.

---

## CEO Directive (`$` prefix)

**Messages starting with `$` are Claw-Empire CEO Directives.**

When receiving a message that **starts with `$`**:

### Step 1: Detect user language

Detect the language of the `$` message and use that language for ALL subsequent interactions in this flow.

### Step 2: Ask about team leader meeting

**Before sending the directive to the server, ALWAYS ask the user whether to convene a team leader meeting.**

Ask in the user's detected language:
- KO: `팀장 소집 회의를 진행할까요?\n1️⃣ 회의 진행 (기획팀 주관)\n2️⃣ 회의 없이 바로 실행`
- EN: `Convene a team leader meeting?\n1️⃣ Hold meeting (led by Planning)\n2️⃣ Execute without meeting`
- JA: `チームリーダー会議を開きますか？\n1️⃣ 会議を開催（企画チーム主導）\n2️⃣ 会議なしで直接実行`
- ZH: `召集组长会议吗？\n1️⃣ 召开会议（企划组主导）\n2️⃣ 不开会直接执行`

**Wait for the user's response before proceeding.**

### Step 3: Ask project path/context

After meeting choice is confirmed, ask where to run the work.

Ask in the user's detected language:
- KO: `작업 기준 프로젝트(경로)가 있을까요?\n예: /Users/me/Projects/climpire\n또는: 기존 작업하던 climpire 프로젝트 / 신규 프로젝트`
- EN: `Which project path/context should we use?\nExample: /Users/me/Projects/climpire\nOr: existing climpire project / new project`
- JA: `作業対象のプロジェクト（パス/コンテキスト）はありますか？\n例: /Users/me/Projects/climpire\nまたは: 既存の climpire プロジェクト / 新規プロジェクト`
- ZH: `本次任务的项目路径/上下文是什么？\n例如: /Users/me/Projects/climpire\n或者: 之前在做的 climpire 项目 / 新项目`

**Wait for the user's response before proceeding.**

### Step 4: Send directive to server

Based on the user's answers:
- Use `skipPlannedMeeting` from the meeting choice.
- If the user gave an exact path, include `"project_path":"<path>"`.
- If the user gave fuzzy context (e.g., "existing climpire project", "new project"), include `"project_context":"<text>"`.

**Option 1 — With meeting (default):**
```bash
curl -X POST http://127.0.0.1:__PORT__/api/inbox \
  -H 'content-type: application/json' \
  -d '{"source":"telegram","text":"$<message content>","author":"<sender>","project_path":"<optional path>","project_context":"<optional context>"}'
```

**Option 2 — Without meeting:**
```bash
curl -X POST http://127.0.0.1:__PORT__/api/inbox \
  -H 'content-type: application/json' \
  -d '{"source":"telegram","text":"$<message content>","author":"<sender>","skipPlannedMeeting":true,"project_path":"<optional path>","project_context":"<optional context>"}'
```

**Do NOT modify the directive text.** Use `"skipPlannedMeeting": true` in the JSON body to skip the meeting. The directive message is passed to agents as-is.

### Step 5: Confirm

Reply with **only a short confirmation** in the user's language:
- KO: `✅ Claw-Empire 업무지시 전달 완료` (회의 진행) / `✅ Claw-Empire 업무지시 전달 완료 (회의 생략)` (회의 없이)
- EN: `✅ Directive sent` (with meeting) / `✅ Directive sent (no meeting)` (without meeting)
- JA: `✅ 指令を送信しました` (会議あり) / `✅ 指令を送信しました（会議なし）` (会議なし)
- ZH: `✅ 指令已发送` (召开会议) / `✅ 指令已发送（免会议）` (不开会)

**NEVER attach additional information** — no OAuth status, no settings, no agent lists, no server response JSON, no provider details. Confirmation message only.

### What happens on the server

The Claw-Empire server detects the `$` prefix and automatically:
- Broadcasts a company-wide announcement
- If meeting: Planning team leader convenes a team leader meeting -> discussion -> agent assignment -> CLI execution
- If no meeting: Planning team leader directly delegates to the best agent -> CLI execution

Without `$`, the message is treated as a general announcement.

---

## Task Orchestration (`#` prefix)

### Core Principle: I am the Orchestrator

**Requests starting with `#` are NOT executed directly.**

I am the PM/Oracle:
- Do NOT directly edit code, run commands, or modify files for `#` requests
- DO register the request on the task board
- DO select the appropriate CLI agent (Claude Code, Codex, Gemini, etc.)
- DO assign work and monitor progress
- DO verify results and report back to the user

**Exception:** Normal conversation, Q&A, and board management itself can be done directly.

---

### 1. Ingestion (Message -> Task Board)

When receiving a message that **starts with `#`**:

1. Recognize it as a task request
2. Strip the `#` prefix and POST to the API:
   ```bash
   curl -X POST http://127.0.0.1:__PORT__/api/inbox \
     -H 'content-type: application/json' \
     -d '{"source":"telegram","text":"<message content>"}'
   ```
3. Confirm to the user (in their language):
   - KO: "태스크 등록 완료"
   - EN: "Task registered"
4. **Ask the user for the project path** (in their language):
   - KO: "이 작업을 어떤 프로젝트 경로에서 진행할까요?"
   - EN: "Which project path should this task run in?"
   - Once the user responds, PATCH the task: `{"project_path":"<user-provided-path>"}`
   - If the user provides a path in the original `#` message (e.g. `# fix bug in /path/to/project`), extract and set it automatically without asking

### 2. Task Distribution

When a task appears in Inbox:

1. Analyze content -> select the appropriate CLI agent
   - **Coding tasks**: Claude Code, Codex, or sessions_spawn
   - **Design/creative**: Gemini CLI (exceptional cases)
2. **Check `project_path`** — if empty, ask the user before proceeding
3. **Check for existing work** — if the task has prior terminal logs, ask whether to continue or start fresh
4. Assign to agent and start execution

### 3. Completion Handling

When an agent completes work, **immediately notify the user**:

1. Check result (success/failure)
2. **Send message immediately**:
   - Success: "[task title] completed - [brief summary]"
   - Failure: "[task title] failed - [error summary]"
3. **On success:**
   - Task moves to `Review` automatically
   - Auto-review triggers
   - Review passes -> move to `Done`
4. **On failure:**
   - Analyze error
   - Reassign to same/different agent, or report to user

### 4. Test -> Final Completion

- All tests pass -> notify user of final result
- If commit needed -> request approval (follow git safety rules below)

---

## Project Path Verification

Tasks have an optional `project_path` field that specifies where the agent should work.

### Rules

1. **If `project_path` is set on the task:** use that path as the working directory
2. **If `project_path` is empty:** check the task description for a path
3. **If neither is set:**
   - **NEVER create a temporary directory or guess a path.** No `/tmp/temp/`, no `~/Desktop/`, no fabricated paths. Strictly forbidden.
   - **STOP and ask the user** and WAIT for their response
   - Only after the user provides an explicit path, PATCH the task with `project_path` then call `/run`
   - Do NOT proceed without a confirmed path.

### Existing session check

Before starting a new agent run, check if the task already has previous runs:

```bash
curl "http://127.0.0.1:__PORT__/api/tasks/<id>/terminal?lines=20"
```

If the terminal log exists and contains prior work (non-empty output), ask the user:
- KO: "이 태스크에 이전 작업 내역이 있습니다. 이어서 진행할까요, 새로 시작할까요?"
- EN: "This task has prior work. Continue where it left off, or start fresh?"

### Ingestion with project_path

When creating tasks via webhook, include `project_path` if known:

```bash
curl -X POST http://127.0.0.1:__PORT__/api/inbox \
  -H 'content-type: application/json' \
  -d '{"source":"telegram","text":"fix the build","project_path":"/Users/me/my-project"}'
```

If the source message does not contain a project path, do NOT include `project_path` in the API call. The orchestrator will ask the user before running the agent.

---

## Git Safety Rule

Agents must NOT create commits by default.

### Required workflow

**Work complete -> Test -> Approval -> Commit**

- Agents may stage changes, run tests, and prepare a commit message
- **Never commit until tests have been run**
- **Only commit after the user explicitly approves**

---

## API Reference

```bash
# Health check
curl http://127.0.0.1:__PORT__/api/health

# List all tasks
curl http://127.0.0.1:__PORT__/api/tasks

# List tasks by status
curl "http://127.0.0.1:__PORT__/api/tasks?status=inbox"

# Create task via inbox webhook
curl -X POST http://127.0.0.1:__PORT__/api/inbox \
  -H 'content-type: application/json' \
  -d '{"source":"telegram","text":"<message>"}'

# Send CEO directive ($ prefix included)
curl -X POST http://127.0.0.1:__PORT__/api/inbox \
  -H 'content-type: application/json' \
  -d '{"source":"telegram","text":"$<directive message>"}'

# View task detail
curl http://127.0.0.1:__PORT__/api/tasks/<id>

# Update task fields
curl -X PATCH http://127.0.0.1:__PORT__/api/tasks/<id> \
  -H 'content-type: application/json' \
  -d '{"project_path":"/Users/me/my-project"}'

# View terminal log
curl "http://127.0.0.1:__PORT__/api/tasks/<id>/terminal?lines=50"

# Run agent on a task
curl -X POST http://127.0.0.1:__PORT__/api/tasks/<id>/run

# Stop a running agent
curl -X POST http://127.0.0.1:__PORT__/api/tasks/<id>/stop

# Assign agent to a task
curl -X POST http://127.0.0.1:__PORT__/api/tasks/<id>/assign \
  -H 'content-type: application/json' \
  -d '{"agent_id":"<agent-id>"}'

# List agents
curl http://127.0.0.1:__PORT__/api/agents

# List departments
curl http://127.0.0.1:__PORT__/api/departments

# Get settings
curl http://127.0.0.1:__PORT__/api/settings

# CLI provider status
curl http://127.0.0.1:__PORT__/api/cli-status
```

---

## Response Rules (STRICT)

When processing `$` or `#` commands, the response to the user must be **minimal and clean**:

1. **`$` directive**: After collecting required meeting/path inputs and sending to API, reply with only `✅ Claw-Empire 업무지시 전달 완료` (or language equivalent). Nothing else.
2. **`#` task**: Only `✅ 태스크 등록 완료` (or language equivalent). Nothing else.
3. **NEVER include** in responses:
   - OAuth connection details or token information
   - Server settings or configuration
   - Agent lists or provider status
   - Raw JSON responses from API calls
   - CLI detection results
   - Model configuration details

---

<!-- END claw-empire orchestration rules -->
