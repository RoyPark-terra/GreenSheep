/**
 * Integrations module - IDE integrations (Cursor, etc.)
 */

export * from './types.js';
export * from './CursorHooksInstaller.js';
