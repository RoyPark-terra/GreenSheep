# claw-voice-chat client

React + Tailwind frontend for claw-voice-chat. See the [root README](../README.md) for full documentation.
